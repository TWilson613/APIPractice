﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace TeamProject.Models
{
    public class Team
    {
        public long Id { get; set; }

        [Required]
        public string TeamName { get; set; }
        public bool IsPlaying { get; set; }
        [Required]
        public string HomeLocation { get; set; }
        public List<Player> Players {get; set;}
       
        public Team()
            {
               List<Player> newList = new List<Player>();
               Players = newList;
                }

    }
}